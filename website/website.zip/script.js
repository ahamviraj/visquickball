(() => {
  const config = window.VI_QUICK_BALL_SITE || {};
  const safeHttps = value => {
    try { const url = new URL(value); return url.protocol === "https:" ? url.href : ""; }
    catch (_) { return ""; }
  };
  const download = safeHttps(config.downloadUrl);
  document.querySelectorAll("[data-download-link]").forEach(link => {
    if (download) { link.href = download; link.hidden = false; link.setAttribute("rel", "noopener noreferrer"); }
  });
  if (download) document.querySelectorAll("[data-download-note]").forEach(note => note.hidden = true);

  document.querySelectorAll("[data-year]").forEach(node => node.textContent = String(new Date().getFullYear()));

  const presentation = document.querySelector("[data-presentation]");
  if (presentation) {
    const viewport = presentation.querySelector(".presentation-viewport");
    const slides = Array.from(presentation.querySelectorAll(".promo-slide"));
    const indicators = Array.from(presentation.querySelectorAll("[data-slide-to]"));
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let activeIndex = 0;
    let transitioning = false;
    let transitionTimer = 0;
    let touchStartY = null;
    let touchClaimed = false;

    const updateSlides = () => {
      slides.forEach((slide, index) => {
        slide.style.setProperty("--slide-offset", `${(index - activeIndex) * 100}%`);
        const active = index === activeIndex;
        slide.classList.toggle("is-active", active);
        slide.setAttribute("aria-hidden", String(!active));
        slide.inert = !active;
      });
      indicators.forEach((button, index) => {
        const active = index === activeIndex;
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-current", String(active));
      });
    };

    const finishTransition = () => {
      if (!transitioning) return;
      transitioning = false;
      window.clearTimeout(transitionTimer);
    };

    const goTo = nextIndex => {
      if (transitioning || nextIndex < 0 || nextIndex >= slides.length || nextIndex === activeIndex) return false;
      activeIndex = nextIndex;
      transitioning = !reducedMotion.matches;
      updateSlides();
      if (transitioning) transitionTimer = window.setTimeout(finishTransition, 650);
      return true;
    };

    slides.forEach(slide => slide.addEventListener("transitionend", event => {
      if (event.target === slide && event.propertyName === "transform") finishTransition();
    }));
    indicators.forEach(button => button.addEventListener("click", () => {
      goTo(Number(button.dataset.slideTo));
    }));

    viewport.addEventListener("wheel", event => {
      if (Math.abs(event.deltaY) < 12) return;
      const nextIndex = activeIndex + (event.deltaY > 0 ? 1 : -1);
      if (nextIndex < 0 || nextIndex >= slides.length) return;
      event.preventDefault();
      goTo(nextIndex);
    }, { passive: false });

    viewport.addEventListener("keydown", event => {
      if (event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
      const nextIndex = activeIndex + (event.key === "ArrowDown" ? 1 : -1);
      if (nextIndex < 0 || nextIndex >= slides.length) return;
      event.preventDefault();
      goTo(nextIndex);
    });

    viewport.addEventListener("touchstart", event => {
      if (event.touches.length !== 1) { touchStartY = null; return; }
      touchStartY = event.touches[0].clientY;
      touchClaimed = false;
    }, { passive: true });
    viewport.addEventListener("touchmove", event => {
      if (touchStartY === null || event.touches.length !== 1) return;
      const delta = touchStartY - event.touches[0].clientY;
      const nextIndex = activeIndex + (delta > 0 ? 1 : -1);
      if (Math.abs(delta) > 12 && nextIndex >= 0 && nextIndex < slides.length) {
        event.preventDefault();
        touchClaimed = true;
      }
    }, { passive: false });
    viewport.addEventListener("touchend", event => {
      if (touchStartY === null) return;
      const endY = event.changedTouches[0]?.clientY;
      const delta = endY === undefined ? 0 : touchStartY - endY;
      touchStartY = null;
      if (touchClaimed && Math.abs(delta) >= 48) goTo(activeIndex + (delta > 0 ? 1 : -1));
      touchClaimed = false;
    }, { passive: true });
    viewport.addEventListener("touchcancel", () => { touchStartY = null; touchClaimed = false; }, { passive: true });

    updateSlides();
  }

  const lightbox = document.querySelector(".lightbox");
  if (lightbox && typeof lightbox.showModal === "function") {
    const image = lightbox.querySelector("img");
    const caption = lightbox.querySelector("figcaption");
    const close = lightbox.querySelector(".lightbox-close");

    document.querySelectorAll("[data-lightbox]").forEach(link => {
      link.addEventListener("click", event => {
        event.preventDefault();
        const thumbnail = link.querySelector("img");
        image.src = link.href;
        image.alt = thumbnail.alt;
        caption.textContent = link.closest("figure")?.querySelector("figcaption")?.textContent || thumbnail.alt;
        lightbox.showModal();
        close.focus();
      });
    });

    close.addEventListener("click", () => lightbox.close());
    lightbox.addEventListener("click", event => {
      if (event.target === lightbox) lightbox.close();
    });
  }
})();
